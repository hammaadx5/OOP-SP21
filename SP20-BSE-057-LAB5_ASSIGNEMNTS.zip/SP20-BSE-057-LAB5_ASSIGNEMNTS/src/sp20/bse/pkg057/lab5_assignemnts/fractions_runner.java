/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sp20.bse.pkg057.lab5_assignemnts;

/**
 *
 * @author 123
 */
public class fractions_runner {
    public static void main(String[] args){
        fractions f1 = new fractions();
        fractions f2 = new fractions();
        f2.setM(32);
        f2.setN(4);
        f1.display();
        f2.display();
        System.out.println("Identical Ratios: "+f1.equals(f1,f2));
        }
}
