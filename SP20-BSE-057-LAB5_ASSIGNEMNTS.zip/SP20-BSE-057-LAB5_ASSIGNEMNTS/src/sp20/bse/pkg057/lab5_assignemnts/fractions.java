/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sp20.bse.pkg057.lab5_assignemnts;

/**
 *
 * @author 123
 */

  public class fractions {
    private int m;
    private int n;
    private int o;
    public fractions(){
        m = 6;
        n = 4;
    }
    public fractions(int m, int n){
        this.m = m;
        this.n = n;
    }
    public void setM(int m){
        this.m = m;
    }
    public void setN(int n){
        this.n = n;
    }
    public int getM(){
        return m;
    }
    public int getN(){
        return n;
    }
    public boolean equals(fractions f1, fractions f2){
        if(f1 == f2)
            return true;
        
        else
            return false;
    }
   public void display(){
   
        System.out.println("Ratio: "+m/n);
    }
  }

    


