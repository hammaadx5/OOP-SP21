/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_a1;

/**
 *
 * @author 123
 */
public class runnerhotdogs {
    public static void main(String[] args) {
		hotdogs a=new hotdogs(12,16);
        a.justsold();
        a.DISPLAY();
        hotdogs b=new hotdogs(15,16);
        b.justsold();
        b.DISPLAY();
        hotdogs c=new hotdogs(1,16);
        c.justsold();
        c.DISPLAY();
	}
}
    

