/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_a1;

/**
 *
 * @author 123
 */
public class hotdogs {

        private int ID;
	private int HDsold;
	


        public hotdogs() {
        
    	ID=00;
    	HDsold=00;
    }
    
    public hotdogs(int i,int s) {
    	ID = i;
    	HDsold = s;
    	
    }
    public void justsold() {
    	HDsold++;
    }
    
    public void DISPLAY() {
    	System.out.println("Stand's ID number: "+ID+"\nNumber of hotdogs sold: "+HDsold);
    }

}
    

