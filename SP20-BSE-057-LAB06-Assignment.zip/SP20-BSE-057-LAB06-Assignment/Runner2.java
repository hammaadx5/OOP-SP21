public class runner {
    public static void main(String[] args) {
        SavingsAccount saver1, saver2;
        saver1 = new SavingsAccount (2000.0);
        saver2= new SavingsAccount (3000.0);

        int total = 0;

        //Set the annual interest rate to 3%=0.03
        SavingsAccount.modifyInterestRate (0.03);

        //Calculate monthly interest
        saver1.calculateMonthly_Interest();
        saver2.calculateMonthly_Interest();

        //Print out the new balances for both savers
        System.out.println("This month:\nSaver 1 balance= "+ saver1.getSavings_Balance());
        System.out.println("Saver 2 balance= "+ saver2.getSavings_Balance());


        //Change annual interest rate to 4%=0.04
        SavingsAccount.modifyInterestRate(0.04);

        //Calculate the next month interest rate and print out balances
        saver1.calculateMonthly_Interest();
        saver2.calculateMonthly_Interest();
        System.out.println("Next month>>\nSaver 1 balance= "+ saver1.getSavings_Balance());
        System.out.println("Saver 2 balance= "+ saver2.getSavings_Balance());

    }
}