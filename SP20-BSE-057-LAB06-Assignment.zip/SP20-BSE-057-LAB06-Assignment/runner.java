public class Runner {
    public static void main(String[] args) {
        CountObjects obj1 = new CountObjects();
        CountObjects obj2 = new CountObjects(31);
        CountObjects obj3 = new CountObjects(32);

        System.out.println("The total number of objects that are created are>> " + obj1.Total_objects());

    }
}