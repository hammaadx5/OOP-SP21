public class SavingsAccount {
    private static double Annual_Interest_Rate;
    private double Savings_Balance;


    public SavingsAccount()
    {
        Savings_Balance = 0;
        Annual_Interest_Rate = 0;
    }

    public SavingsAccount(double balance)
    {
        this.Savings_Balance = balance;
        Annual_Interest_Rate = 0;
    }

    public void calculateMonthly_Interest()
    {
        double monthlyInt;
        monthlyInt= (double)(this.Savings_Balance*Annual_Interest_Rate/12);
        this.Savings_Balance+=monthlyInt;
    }

    public static void modifyInterestRate(double newAnnualInterestRate)
    {
        Annual_Interest_Rate = newAnnualInterestRate;
    }

    public double getSavingsBalance()
    {
        return Savings_Balance;
    }






}