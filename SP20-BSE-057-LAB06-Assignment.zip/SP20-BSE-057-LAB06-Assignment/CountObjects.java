public class CountObjects {

    private static int object_count = 0;
    private static int s;
    public CountObjects(){
        object_count++;

    }
    public CountObjects(int object){
        s = object;
        object_count++;
    }
    public static int Total_objects() {
        return object_count;

    }
    }