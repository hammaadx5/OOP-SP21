
package ooplab14;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

@SuppressWarnings("SERIAL")
public class Account implements Serializable {
	private String name;
	private int Account_Number, Bank_Balance = 1000;

	Scanner keyboard = new Scanner(System.in);

	public Account(String name, int Account_Number) {
		super();
		this.name = name;
		this.Account_Number = Account_Number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Account [ Name: " + name + " Account number: " + Account_Number + " Bank Balance: " + Bank_Balance + "]\n";
	}

	public int getAccountNum() {
		return Account_Number;
	}

	public void setAccountNum(int Account_Number) {
		this.Account_Number = Account_Number;
	}

	public int getBankBalance() {
		return Bank_Balance;
	}

	public void setBankBalance(int bankBalance) {
		this.Bank_Balance += bankBalance;
	}

	public void withDraw() {

		System.out.println("Enter the amount you want to withdraw: ");
		int cash = keyboard.nextInt();
		Bank_Balance -= cash;
		System.out.println("Cash has been withdrawn!!! \nbalance: " + Bank_Balance);

	}

	public void deposit() {

		System.out.println("Enter the amount you want to deposit: ");
		int cash = keyboard.nextInt();
		Bank_Balance += cash;
		System.out.println("Cash has been deposited!!! \nbalance: " + Bank_Balance);

	}

	public void balanceCheck() {
		int balance = getBankBalance();
		System.out.println("Your balance is: " + balance);
	}

	public void transfer(Account to, Account from) {

		System.out.println("Enter the amount you want to transfer: ");
		int cash = keyboard.nextInt();
		to.setBankBalance(Bank_Balance + cash);
		from.setBankBalance(Bank_Balance - cash);
		System.out.println(cash + " transfered Successfully");

	}

	public static void writeFile(ArrayList<Account> record) {
		FileOutputStream bookStream;
		try {


			bookStream = new FileOutputStream("E:\\Account.txt");
			ObjectOutputStream objectStream = new ObjectOutputStream(bookStream);
			objectStream.writeObject(record.toString());
			objectStream.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void readFile(ArrayList<Account> record) {

		try {


			FileInputStream inputStream = new FileInputStream("E:\\Account.txt");
			ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
			System.out.println(objectInputStream.readObject());

			objectInputStream.close();

		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
