
package ooplab14;


import java.io.FileNotFoundException;

import java.util.ArrayList;

public class Runner {

	public static void main(String[] args) throws FileNotFoundException {

		Account u1 = new Account("user1", 1);
		Account u2 = new Account("user2", 2);
		Account u3 = new Account("user3", 3);
		Account u4 = new Account("user4", 4);
		Account u5 = new Account("user5", 5);
		Account u6 = new Account("user6", 6);
		Account u7 = new Account("user7", 7);
		Account u8 = new Account("user8", 8);
		Account u9 = new Account("user9", 9);
		Account u10 = new Account("user10", 10);

		ArrayList<Account> record = new ArrayList<Account>();
		record.add(u1);
		record.add(u2);
		record.add(u3);
		record.add(u4);
		record.add(u5);
		record.add(u6);
		record.add(u7);
		record.add(u8);
		record.add(u9);
		record.add(u10);

		Account.writeFile(record);

		u1.deposit();
		u2.balanceCheck();
		u3.withDraw();
		u4.transfer(u5, u4);
		
				
		Account.writeFile(record);
		Account.readFile(record);

	}

}
